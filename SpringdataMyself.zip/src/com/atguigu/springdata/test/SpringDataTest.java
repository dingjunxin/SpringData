package com.atguigu.springdata.test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.domain.Specification;

import com.atguigu.springdata.Person;
import com.atguigu.springdata.PersonRepsotory;
import com.atguigu.springdata.PersonService;

public class SpringDataTest {

	private ApplicationContext ctx = null;
	private PersonRepsotory personRepsotory = null;
	private PersonService personService;

	{
		ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		personRepsotory = ctx.getBean(PersonRepsotory.class);
		personService = ctx.getBean(PersonService.class);

	}

	// 创建表
	@Test
	public void testJpa() {

	}

	// 测试是否与数据库连接
	@Test
	public void testDataSource() throws SQLException {
		DataSource dataSource = ctx.getBean(DataSource.class);
		System.out.println(dataSource.getConnection());
	}

	// 根据名称返回信息
	@Test
	public void testHelloWorldSpringData()
			throws FileNotFoundException, IOException, InstantiationException, IllegalAccessException {
		System.out.println(personRepsotory.getClass().getName());

		Person person = personRepsotory.getByLastName("admin");
		System.out.println(person);
	}

	// 根据条件返回信息
	@Test
	public void testKeyWords() {
		List<Person> persons = personRepsotory.getByLastNameStartingWithAndIdLessThan("X", 10);
		System.out.println(persons);

		persons = personRepsotory.getByLastNameEndingWithAndIdLessThan("X", 10);
		System.out.println(persons);

		persons = personRepsotory.getByEmailInAndBirthLessThan(Arrays.asList("1", "2", "3"), new Date());
		System.out.println(persons.size());
	}
	//级联查询
	/**
	 * Hibernate: 
    select
        person0_.id as id1_1_,
        person0_.address_id as address_6_1_,
        person0_.add_id as add_id2_1_,
        person0_.birth as birth3_1_,
        person0_.email as email4_1_,
        person0_.last_name as last_nam5_1_ 
    from
        jpa_persons person0_ 
    left outer join
        jpa_addresses address1_ 
            on person0_.address_id=address1_.id 
    where
        address1_.id>?
[]
	 */
	@Test
	public void testKeyWords2() {
		List<Person> persons = personRepsotory.getByAddress_IdGreaterThan(1);
		System.out.println(persons);
	}
	
	//利用Query实现子查询
	/**
	 * Hibernate: 
    select
        person0_.id as id1_1_,
        person0_.address_id as address_6_1_,
        person0_.add_id as add_id2_1_,
        person0_.birth as birth3_1_,
        person0_.email as email4_1_,
        person0_.last_name as last_nam5_1_ 
    from
        jpa_persons person0_ 
    where
        person0_.id=(
            select
                max(person1_.id) 
            from
                jpa_persons person1_
        )
Person [id=4, lastName=VX, email=2, brith=2018-10-07 16:47:47.0]
	 */
	@Test
	public void testQueryAnnotation(){
		Person person = personRepsotory.getMaxIdPerson();
		System.out.println(person);
	}
	
	//利用Query传递参数
	/**
	 * Hibernate: 
    select
        person0_.id as id1_1_,
        person0_.address_id as address_6_1_,
        person0_.add_id as add_id2_1_,
        person0_.birth as birth3_1_,
        person0_.email as email4_1_,
        person0_.last_name as last_nam5_1_ 
    from
        jpa_persons person0_ 
    where
        person0_.last_name=? 
        and person0_.email=?
[Person [id=3, lastName=XX, email=1, brith=2018-10-07 16:47:31.0]]
	 */
	@Test
	public void testQueryAnnotationParams1(){
		List<Person> persons = personRepsotory.testQueryAnnotationParams1("XX", "1");
		System.out.println(persons);
	}
	
	//为 @Query 注解传递参数的方式1: 命名参数的方式. 
	/**
	 * Hibernate: 
    select
        person0_.id as id1_1_,
        person0_.address_id as address_6_1_,
        person0_.add_id as add_id2_1_,
        person0_.birth as birth3_1_,
        person0_.email as email4_1_,
        person0_.last_name as last_nam5_1_ 
    from
        jpa_persons person0_ 
    where
        person0_.last_name=? 
        and person0_.email=?
[Person [id=3, lastName=XX, email=1, brith=2018-10-07 16:47:31.0]]
	 */
	@Test
	public void testQueryAnnotationParams2(){
		List<Person> persons = personRepsotory.testQueryAnnotationParams2("1", "XX");
		System.out.println(persons);
	}
	
/**
 * Hibernate: 
    select
        person0_.id as id1_1_,
        person0_.address_id as address_6_1_,
        person0_.add_id as add_id2_1_,
        person0_.birth as birth3_1_,
        person0_.email as email4_1_,
        person0_.last_name as last_nam5_1_ 
    from
        jpa_persons person0_ 
    where
        person0_.last_name like ? 
        or person0_.email like ?
2
 */
	@Test
	public void testQueryAnnotationLikeParam(){
//		List<Person> persons = personRepsotory.testQueryAnnotationLikeParam("%X%", "%2%");
//		System.out.println(persons.size());
		
//		List<Person> persons = personRepsotory.testQueryAnnotationLikeParam("X", "2");
//		System.out.println(persons.size());
		
		List<Person> persons = personRepsotory.testQueryAnnotationLikeParam2("2", "X");
		System.out.println(persons.size());
	}
//查看有多少数据
/**
 * Hibernate: 
    SELECT
        count(id) 
    FROM
        jpa_persons
3
 */
	@Test
	public void testNativeQuery(){
		long count = personRepsotory.getTotalCount();
		System.out.println(count);
	}
	
	//修改数据
	/**
	 * Hibernate: 
    update
        jpa_persons 
    set
        email=? 
    where
        id=?
	 */
	@Test
	public void testModifying(){
		//错误：需要事务，所有定义一个Service层
		//personRepsotory.updatePersonEmail(1, "mmmm@atguigu.com");
		personService.updatePersonEmail("mmmm@atguigu.com", 2);
	}
	
	//利用CrudRepository接口实现保存，需要在Service上面添加该方法（级联添加）
	/**
	 * Hibernate: 
    insert 
    into
        jpa_persons
        (address_id, add_id, birth, email, last_name) 
    values
        (?, ?, ?, ?, ?)
Hibernate: 
    insert 
    into
        jpa_persons
        (address_id, add_id, birth, email, last_name) 
    values
        (?, ?, ?, ?, ?)

	 */
	@Test
	public void testCrudReposiory(){
		List<Person> persons = new ArrayList<>();
		
		for(int i = 'a'; i <= 'z'; i++){
			Person person = new Person();
			person.setAddressId(i + 1);
			person.setBirth(new Date());
			person.setEmail((char)i + "" + (char)i + "@atguigu.com");
			person.setLastName((char)i + "" + (char)i);
			
			persons.add(person);
		}
		
		personService.savePersons(persons);
	}
	
	//利用PagingAndSortingRepository接口进行分页
	/**
	 * Hibernate: 
    select
        count(*) as col_0_0_ 
    from
        jpa_persons person0_
Hibernate: 
    select
        person0_.id as id1_1_,
        person0_.address_id as address_6_1_,
        person0_.add_id as add_id2_1_,
        person0_.birth as birth3_1_,
        person0_.email as email4_1_,
        person0_.last_name as last_nam5_1_ 
    from
        jpa_persons person0_ 
    order by
        person0_.id desc,
        person0_.email asc limit ?,
        ?
总记录数: 30
当前第几页: 6
总页数: 6
当前页面的 List: [Person [id=6, lastName=bb, email=bb@atguigu.com, brith=2018-10-07 20:32:14.0], 
				Person [id=5, lastName=aa, email=aa@atguigu.com, brith=2018-10-07 20:32:14.0],
 				Person [id=4, lastName=VX, email=2, brith=2018-10-07 16:47:47.0],
  				Person [id=3, lastName=XX, email=1, brith=2018-10-07 16:47:31.0],
   				Person [id=2, lastName=admin, email=mmmm@atguigu.com, brith=2018-10-07 16:45:37.0]]
当前页面的记录数: 5
	 */
	@Test
	public void testPagingAndSortingRespository(){
		//pageNo 从 0 开始. 
		int pageNo = 6 - 1;
		int pageSize = 5;
		//Pageable 接口通常使用的其 PageRequest 实现类. 其中封装了需要分页的信息
		//排序相关的. Sort 封装了排序的信息
		//Order 是具体针对于某一个属性进行升序还是降序. 
		Order order1 = new Order(Direction.DESC, "id");
		Order order2 = new Order(Direction.ASC, "email");
		Sort sort = new Sort(order1, order2);
		
		PageRequest pageable = new PageRequest(pageNo, pageSize, sort);
		Page<Person> page = personRepsotory.findAll(pageable);
		
		System.out.println("总记录数: " + page.getTotalElements());
		System.out.println("当前第几页: " + (page.getNumber() + 1));
		System.out.println("总页数: " + page.getTotalPages());
		System.out.println("当前页面的 List: " + page.getContent());
		System.out.println("当前页面的记录数: " + page.getNumberOfElements());
	}
	
	//继承JpaRepository接口，实现保存，更新方法
	/**
	 * Hibernate: 
    select
        person0_.id as id1_1_0_,
        person0_.address_id as address_6_1_0_,
        person0_.add_id as add_id2_1_0_,
        person0_.birth as birth3_1_0_,
        person0_.email as email4_1_0_,
        person0_.last_name as last_nam5_1_0_ 
    from
        jpa_persons person0_ 
    where
        person0_.id=?
Hibernate: 
    update
        jpa_persons 
    set
        address_id=?,
        add_id=?,
        birth=?,
        email=?,
        last_name=? 
    where
        id=?
false
	 */
	@Test
	public void testJpaRepository(){
		Person person = new Person();
		person.setBirth(new Date());
		person.setEmail("XX@atguigu.com");
		person.setLastName("xyz");
		person.setId(32);
		
		Person person2 = personRepsotory.saveAndFlush(person);
		
		System.out.println(person == person2);
	}
	
	//继承JpaSpecificationExecutor接口
	/**
	 * 目标: 实现带查询条件的分页. id > 5 的条件
	 * 
	 * 调用 JpaSpecificationExecutor 的 Page<T> findAll(Specification<T> spec, Pageable pageable);
	 * Specification: 封装了 JPA Criteria 查询的查询条件
	 * Pageable: 封装了请求分页的信息: 例如 pageNo, pageSize, Sort
	 */
	@Test
	public void testJpaSpecificationExecutor(){
		int pageNo = 3 - 1;
		int pageSize = 5;
		PageRequest pageable = new PageRequest(pageNo, pageSize);
		
		//通常使用 Specification 的匿名内部类
		Specification<Person> specification = new Specification<Person>() {
			/**
			 * @param *root: 代表查询的实体类. 
			 * @param query: 可以从中可到 Root 对象, 即告知 JPA Criteria 查询要查询哪一个实体类. 还可以
			 * 来添加查询条件, 还可以结合 EntityManager 对象得到最终查询的 TypedQuery 对象. 
			 * @param *cb: CriteriaBuilder 对象. 用于创建 Criteria 相关对象的工厂. 当然可以从中获取到 Predicate 对象
			 * @return: *Predicate 类型, 代表一个查询条件. 
			 */
			@Override
			public Predicate toPredicate(Root<Person> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path path = root.get("id");
				Predicate predicate = cb.gt(path, 5);
				return predicate;
			}
		};
		
		Page<Person> page = personRepsotory.findAll(specification, pageable);
		
		System.out.println("总记录数: " + page.getTotalElements());
		System.out.println("当前第几页: " + (page.getNumber() + 1));
		System.out.println("总页数: " + page.getTotalPages());
		System.out.println("当前页面的 List: " + page.getContent());
		System.out.println("当前页面的记录数: " + page.getNumberOfElements());
	}
	
	//继承自己定义的Dao
	/**
	 * Hibernate: 
    select
        person0_.id as id1_1_1_,
        person0_.address_id as address_6_1_1_,
        person0_.add_id as add_id2_1_1_,
        person0_.birth as birth3_1_1_,
        person0_.email as email4_1_1_,
        person0_.last_name as last_nam5_1_1_,
        address1_.id as id1_0_0_,
        address1_.city as city2_0_0_,
        address1_.province as province3_0_0_ 
    from
        jpa_persons person0_ 
    left outer join
        jpa_addresses address1_ 
            on person0_.address_id=address1_.id 
    where
        person0_.id=?
-->Person [id=11, lastName=gg, email=gg@atguigu.com, brith=2018-10-07 20:32:14.0]

	 */
	@Test
	public void testCustomRepositoryMethod(){
		personRepsotory.test();
	}
}
